#include "InterfazDeUsuario.h"

void InterfazDeUsuario::mostrarMenuPrincipal() {
    int opcion;
    do {
        cout << "Men� Principal" << endl;
        cout << "1- Submen� Administraci�n" << endl;
        cout << "2- Submen� Control de Citas" << endl;
        cout << "3- Submen� B�squedas y Listados" << endl;
        cout << "Ingrese la opci�n: ";
        cin >> opcion;

        switch (opcion) {
        case 1:
            mostrarSubmenuAdministracion();
            break;
        case 2:
            mostrarSubmenuControlCitas();
            break;
        case 3:
            mostrarSubmenuBusquedasYListados();
            break;
        default:
            cout << "Opci�n no v�lida, intente nuevamente." << endl;
            break;
        }
    } while (opcion != 0);
}

void InterfazDeUsuario::mostrarSubmenuAdministracion() {
    int opcion;
    do {
        cout << "Submen� Administraci�n" << endl;
        cout << "(1) Ingresar Especialidades" << endl;
        cout << "(2) Ingresar Doctor (por especialidad)" << endl;
        cout << "(3) Ingresar Due�o" << endl;
        cout << "(4) Ingresar Mascota (por due�o)" << endl;
        cout << "(0) Regresar al Men� Principal" << endl;
        cout << "Ingrese la opci�n: ";
        cin >> opcion;

        switch (opcion) {
        case 1:
            ingresarEspecialidad();
            break;
        case 2:
            ingresarDoctor();
            break;
        case 3:
            ingresarDueno();
            break;
        case 4:
            ingresarMascota();
            break;
        case 0:
            cout << "Regresando al Men� Principal..." << endl;
            break;
        default:
            cout << "Opci�n no v�lida, intente nuevamente." << endl;
            break;
        }
    } while (opcion != 0);
}

void InterfazDeUsuario::mostrarSubmenuControlCitas() {
    int opcion;
    do {
        cout << "Submen� Control de Citas" << endl;
        cout << "(1) Sacar Cita" << endl;
        cout << "(2) Cancelar Cita" << endl;
        cout << "(3) Mostrar Calendario de Citas por Doctor" << endl;
        cout << "(4) Mostrar Citas por Due�o" << endl;
        cout << "(0) Regresar al Men� Principal" << endl;
        cout << "Ingrese la opci�n: ";
        cin >> opcion;

        switch (opcion) {
        case 1:
            sacarCita();
            break;
        case 2:
            cancelarCita();
            break;
        case 3:
            mostrarCalendarioCitasPorDoctor();
            break;
        case 4:
            mostrarCitasPorDueno();
            break;
        case 0:
            cout << "Regresando al Men� Principal..." << endl;
            break;
        default:
            cout << "Opci�n no v�lida, intente nuevamente." << endl;
            break;
        }
    } while (opcion != 0);
}

void InterfazDeUsuario::mostrarSubmenuBusquedasYListados() {
    int opcion;
    do {
        cout << "Submen� B�squedas y Listados" << endl;
        cout << "(1) Mostrar Listado de Especialidades" << endl;
        cout << "(2) Mostrar Listado de Doctores por Especialidad" << endl;
        cout << "(3) Mostrar Due�os con sus Mascotas" << endl;
        cout << "(4) Mostrar Pacientes por Doctor" << endl;
        cout << "(0) Regresar al Men� Principal" << endl;
        cout << "Ingrese la opci�n: ";
        cin >> opcion;

        switch (opcion) {
        case 1:
            mostrarListadoEspecialidades();
            break;
        case 2:
            mostrarDoctoresPorEspecialidad();
            break;
        case 3:
            mostrarDuenosConMascotas();
            break;
        case 4:
            mostrarPacientesPorDoctor();
            break;
        case 0:
            cout << "Regresando al Men� Principal..." << endl;
            break;
        default:
            cout << "Opci�n no v�lida, intente nuevamente." << endl;
            break;
        }
    } while (opcion != 0);
}
