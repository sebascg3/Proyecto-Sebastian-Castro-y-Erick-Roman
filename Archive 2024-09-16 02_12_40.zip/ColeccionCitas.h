#pragma once
#include "Cita.h"
#include "Mascota.h"
class ColeccionCitas {
private:
    NodoCita* cabeza;
    Mascota* mascota;
public:
    ColeccionCitas();
    ~ColeccionCitas();
    void agregarCita(Cita* cita);
    void eliminarCita(Cita* cita);
    bool hayCitaChocante(Cita* cita);
    string toString() const;
};