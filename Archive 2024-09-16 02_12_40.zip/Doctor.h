#pragma once
#include "Especialidad.h"
#include <string>
#include "Mascota.h"
#include <vector>
using namespace std;

class Doctor {
private:
    string nombre;
    Especialidad* especializacion;
    vector<Mascota*> pacientes;
public:
    Doctor(string nom, Especialidad& esp);

    string getNombre()const;
    void setNombre(string nom);
    string getEspecializacion()const; 
    void setEspecializacion(Especialidad* esp);
    void agregarPaciente(Mascota* nuevaMascota);
    string buscarPacientes() const;

    string toString()const;
};
