#include "ColeccionCitas.h"

ColeccionCitas::ColeccionCitas(): cabeza(nullptr) {}

ColeccionCitas::~ColeccionCitas() {
    NodoCita* actual = cabeza;
    while (actual) {
        NodoCita* temp = actual;
        actual = actual->siguiente;
        delete temp;
    }
}

void ColeccionCitas::agregarCita(Cita* cita) {
    if (cita == nullptr || cita->getDia() < 1 || cita->getDia() > 6) {
        cout << "La cita proporcionada es inv�lida (d�a fuera de rango)." << endl;
        return;
    }
    if (hayCitaChocante(cita)) {
        cout << "La cita choca con una existente." << endl;
        return;
    }

    NodoCita* nuevoNodo = new NodoCita(cita);

    if (!cabeza) {
        cabeza = nuevoNodo;
    }
    else {
        NodoCita* actual = cabeza;
        while (actual->siguiente) {
            actual = actual->siguiente;
        }
        actual->siguiente = nuevoNodo;
    }
}

void ColeccionCitas::eliminarCita(Cita* cita) {
    if (!cabeza) return;

    NodoCita* actual = cabeza;
    NodoCita* anterior = nullptr;

    while (actual && !(actual->cita->chocaCon(*cita))) { 
        anterior = actual;
        actual = actual->siguiente;
    }

    if (actual) {
        if (anterior) {
            anterior->siguiente = actual->siguiente;
        }
        else {
            cabeza = actual->siguiente;
        }
        delete actual;
    }
}
bool ColeccionCitas::hayCitaChocante(Cita* cita) {
    NodoCita* actual = cabeza;
    while (actual) {
        if (actual->cita->chocaCon(*cita)) {
            return true;
        }
        actual = actual->siguiente;
    }
    return false;
}

string ColeccionCitas::toString() const {
    stringstream s;
    NodoCita* actual = cabeza;
    while (actual) {
        s << actual->cita->toString() << endl;
        actual = actual->siguiente;
    }
    return s.str();
}
