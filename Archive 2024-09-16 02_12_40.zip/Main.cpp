#include <iostream>
#include "ColeccionCitas.h"


using namespace std;

int main() {
    ColeccionCitas citas;

    Cita cita1(1, "10:00");
    Cita cita2(2, "11:00");
    Cita cita3(1, "12:00"); 

    citas.agregarCita(&cita1);
    citas.agregarCita(&cita2);

    //try {
    //    citas.agregarCita(&cita3);
    //}
    //catch (const exception& e) {
    //    cout << "Error: " << e.what() << endl;
    //}

    cout << citas.toString();

	return 0;
}
